export default class FooterComponent extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
  }
  connectedCallback() {
    this.render();
  }
  render(){
    this.shadowRoot.innerHTML = `
      <style>
        p{
          text-align: center;
        }
      </style>
      <p>&copy; Notes App</p> <p>Designed with By Hanif</p>
    `
  }
}
customElements.define('footer-component', FooterComponent);
