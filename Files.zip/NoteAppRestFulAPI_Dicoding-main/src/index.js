//index,js
import 'regenerator-runtime'
import 'bootstrap/dist/css/bootstrap.min.css'
import './styles/styles.css'
import './scripts/Scripts'


