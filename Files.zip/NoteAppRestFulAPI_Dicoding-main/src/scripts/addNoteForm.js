class AddNoteForm extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }

    connectedCallback() {
        this.render();
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
                /* Add your styles here */
            </style>
            <form id="noteForm">
                <label for="title">Title</label>
                <input type="text" id="title" name="title" required>
                <label for="body">Body</label>
                <textarea id="body" name="body" required></textarea>
                <button type="submit">Add Note</button>
            </form>
        `;

        this.shadowRoot.querySelector('#noteForm').addEventListener('submit', this.handleSubmit.bind(this));
    }

    async handleSubmit(event) {
        event.preventDefault();
        const title = this.shadowRoot.querySelector('#title').value;
        const body = this.shadowRoot.querySelector('#body').value;
        
        try {
            const response = await fetch('https://notes-api.dicoding.dev/v2/notes', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ title, body })
            });
            if (!response.ok) {
                throw new Error('Failed to add note');
            }
            const data = await response.json();
            console.log('Note added:', data);
            this.dispatchEvent(new CustomEvent('noteAdded', { detail: data }));
            window.location.reload(); //Tambahkan kode ini
        } catch (error) {
            console.error('Error:', error);
        }
    }
}

customElements.define('add-note-form', AddNoteForm);
