import './addNoteForm';
import './notesComponen';
import './footer';

document.addEventListener('DOMContentLoaded', () => {
    const app = document.getElementById('app');

    const form = document.querySelector('add-note-form');
    form.addEventListener('submit', (event) => {
        event.preventDefault();
        const title = document.getElementById('note-title').value;
        const content = document.getElementById('note-content').value;

        notesComponent.addNote({ title, content });
        app.innerHTML = '';
        app.innerHTML += addNoteForm.render();
        app.innerHTML += notesComponent.render();
        app.innerHTML += footer.render();
    });
});
