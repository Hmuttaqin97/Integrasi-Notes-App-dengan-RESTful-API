class NoteList extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.notes = [];
        this.notesArchived = [];
    }

    connectedCallback() {
        this.render();
        this.fetchNotes();
        this.fetchNoteArchived();
    }

    toggleLoader(){
        document.querySelector('.loader').classList.toggle('show');
    }

    async fetchNotes() {
        try {
            this.toggleLoader(); //Munculkan loader
            const response = await fetch('https://notes-api.dicoding.dev/v2/notes');
            if (!response.ok) {
                throw new Error('Failed to fetch notes');
            }
            const data = await response.json();
            this.notes = data.data;
            this.render();
            this.toggleLoader() //Menghilangkan loader
        } catch (error) {
            console.error('Error:', error);
        }
    }

    async updateNote(noteId, isArchived) {
        try {
            let url = isArchived === "true"
                ? `https://notes-api.dicoding.dev/v2/notes/${noteId}/unarchive`
                : `https://notes-api.dicoding.dev/v2/notes/${noteId}/archive`;
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });
            if (!response.ok) {
                throw new Error('Failed to update note');
            }
            this.fetchNotes();
            this.fetchNoteArchived();
            return response;
        } catch (error) {
            console.error('Error:', error);
        }
    }

    async removeNote(id) {
        try {
            const response = await fetch(`https://notes-api.dicoding.dev/v2/notes/${id}`, {
                method: 'DELETE',
            });
            if (!response.ok) {
                throw new Error('Failed to delete note');
            }
            this.fetchNotes();
            this.fetchNoteArchived();
        } catch (error) {
            console.error('Error:', error);
        }
    }

    async fetchNoteArchived() {
        try {
            const response = await fetch('https://notes-api.dicoding.dev/v2/notes/archived');
            if (!response.ok) {
                throw new Error('Failed to fetch notes');
            }
            const data = await response.json();
            this.notesArchived = data.data;
            this.render();
        } catch (error) {
            console.error('Error:', error);
        }
    }

    render() {
        this.shadowRoot.innerHTML = `
            <style>
            ul {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            }
                    /* Add your styles here */
            </style>
            <h3> Tidak Diarsip</h3>
            <ul>
            ${this.notes.map((note) => `
                    <li>
                        <h2>${note.title}</h2>
                        <p>${note.body}</p>
                        <p>${note.createdAt}</p>
                        <button data-archived=${note.archived} data-id="${note.id}" class="move-button">Pindah</button>
                        <button data-id="${note.id}" class="delete-button">Delete</button>
                    </li>
                `).join('')}
            </ul>
            <h3>Diarsip</h3>
            <ul>
                ${this.notesArchived.map((note) => `
                    <li>
                        <h2>${note.title}</h2>
                        <p>${note.body}</p>
                        <p>${note.createdAt}</p>
                        <button data-archived=${note.archived} data-id="${note.id}" class="move-button">Pindah</button>
                        <button data-id="${note.id}" class="delete-button">Delete</button>
                    </li>
                `).join('')}
            </ul>
            `;
        this.shadowRoot.querySelectorAll('.delete-button').forEach((button) => {
            button.addEventListener('click', (event) => {
                const noteId = event.target.dataset.id;
                this.removeNote(noteId);
            });
        });
        this.shadowRoot.querySelectorAll('.move-button').forEach((button) => {
            button.addEventListener('click', (event) => {
                const noteId = event.target.dataset.id;
                const isArchived = event.target.dataset.archived;
                this.updateNote(noteId, isArchived);
            });
        });
    }
} //Tambahkan ini
customElements.define('notes-list', NoteList);
